<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ApiServiceController extends Controller
{
    //
}

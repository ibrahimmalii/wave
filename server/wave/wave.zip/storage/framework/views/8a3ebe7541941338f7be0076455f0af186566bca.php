<?php $__env->startSection('page_title', __('voyager::generic.'.(isset($dataTypeContent->id) ? 'edit' : 'add')).' '.$dataType->getTranslatedAttribute('display_name_singular')); ?>

<?php $__env->startSection('css'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
<h1 class="page-title">
    <i class="<?php echo e($dataType->icon); ?>"></i>
    <?php echo e(__('voyager::generic.'.(isset($dataTypeContent->id) ? 'edit' : 'add')).' '.$dataType->getTranslatedAttribute('display_name_singular')); ?>

</h1>
<?php $__env->stopSection(); ?>

<?php
use Carbon\Carbon;
$date = Carbon::now();
$date->toDateString();
$date->addMonths(1);
?>

<?php $__env->startSection('content'); ?>
<div class="page-content container-fluid">
    <form class="form-edit-add" role="form" action="<?php if(!is_null($dataTypeContent->getKey())): ?><?php echo e(route('voyager.'.$dataType->slug.'.update', $dataTypeContent->getKey())); ?><?php else: ?><?php echo e(route('voyager.'.$dataType->slug.'.store')); ?><?php endif; ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
        <!-- PUT Method if we are editing -->
        <?php if(isset($dataTypeContent->id)): ?>
        <?php echo e(method_field("PUT")); ?>

        <?php endif; ?>
        <?php echo e(csrf_field()); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-bordered">
                    
                    <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <div class="panel-body" style="direction:rtl">
                        <div class="form-group">
                            <label for="paid_service_id"> الخدمة المدفوعة</label>
                            <select class="form-control select2" id="paid_service_id" name="paid_service_id">
                                <?php $__currentLoopData = App\Models\Service::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($locale['id']); ?>"><?php echo e($locale['title_subtitle']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <!-- <input type="text" class="form-control" id="paid_service_id" name="paid_service_id" value="<?php echo e(old('paid_service_id', $dataTypeContent->paid_service_id ?? '')); ?>"> -->
                        </div>

                        <div class="form-group">
                            <label for="free_service_id"> الخدمة المجانية</label>
                            <select class="form-control select2" id="free_service_id" name="free_service_id">
                                <?php $__currentLoopData = App\Models\Service::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($locale['id']); ?>"><?php echo e($locale['title_subtitle']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <!-- <input type="text" class="form-control" id="free_service_id" name="free_service_id" value="<?php echo e(old('free_service_id', $dataTypeContent->free_service_id ?? '')); ?>"> -->
                        </div>

                        <div class="form-group">
                            <label for="title">العنوان باللغة الانجليزية</label>
                            <input type="text" class="form-control" id="title" name="title" value="<?php echo e(old('title', $dataTypeContent->title ?? '')); ?>">
                        </div>

                        <div class="form-group">
                            <label for="title_subtitle"> العنوان باللغة العربية</label>
                            <input type="text" class="form-control" id="title_subtitle" name="title_subtitle" value="<?php echo e(old('title_subtitle', $dataTypeContent->title_subtitle ?? '')); ?>">
                        </div>

                        <div class="form-group">
                            <label for="description">الوصف باللغة الانجليزية</label>
                            <input type="text" class="form-control" id="description" name="description" value="<?php echo e(old('description', $dataTypeContent->description ?? '')); ?>">
                        </div>

                        <div class="form-group">
                            <label for="description_subtitle"> الوصف باللغة العربية</label>
                            <input type="text" class="form-control" id="description_subtitle" name="description_subtitle" value="<?php echo e(old('description_subtitle', $dataTypeContent->description_subtitle ?? '')); ?>">
                        </div>

                        <div class="form-group">
                            <label for="paid_count">عدد الخدمات المدفوعة</label>
                            <input type="text" class="form-control" id="paid_count" name="paid_count" value="<?php echo e(old('paid_count', $dataTypeContent->paid_count ?? '')); ?>">
                        </div>

                        <div class="form-group">
                            <label for="free_count">عدد الخدمات المجانية</label>
                            <input type="text" class="form-control" id="free_count" name="free_count" value="<?php echo e(old('free_count', $dataTypeContent->free_count ?? '')); ?>">
                        </div>

                        <div class="form-group">
                            <input type="hidden" class="form-control" id="type" name="type" value="1">
                        </div>

                        <div class="form-group">
                            <label for="locale">الحالة</label>
                            <select class="form-control select2" id="active" name="active">
                                <option value="1">نشط</option>
                                <option value="0">غبر نشط</option>
                            </select>
                        </div>

                        <!-- <div class="form-group">
                            <label for="locale">لغة</label>
                            <select class="form-control select2" id="locale" name="locale">
                                <?php $__currentLoopData = App\Models\Service::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($locale['id']); ?>"><?php echo e($locale['title_subtitle']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-primary pull-right save">
            حفظ
        </button>
    </form>

    <iframe id="form_target" name="form_target" style="display:none"></iframe>
    <form id="my_form" action="<?php echo e(route('voyager.upload')); ?>" target="form_target" method="post" enctype="multipart/form-data" style="width:0px;height:0;overflow:hidden">
        <?php echo e(csrf_field()); ?>

        <input name="image" id="upload_file" type="file" onchange="$('#my_form').submit();this.value='';">
        <input type="hidden" name="type_slug" id="type_slug" value="<?php echo e($dataType->slug); ?>">
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script>
    $('document').ready(function() {
        $('.toggleswitch').bootstrapToggle();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\UPWORK\WAVE\wave\server\wave\resources\views/vendor/voyager/offers/edit-add.blade.php ENDPATH**/ ?>